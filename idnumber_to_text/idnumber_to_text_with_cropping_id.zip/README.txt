argv[1]: path to image
argv[2]: path to ConvNet architecture
argv[3]: path to caffe model

e.g.
python3 recognise_id_number.py number_id_test/many_digit_groups/841289701567_0901315908_023841227_1_2016032415243805.jpgcardnumber.png lenet_deploy.prototxt mixed_lenet_8817_id_digit.caffemodel
