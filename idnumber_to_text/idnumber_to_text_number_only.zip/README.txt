argv[1]: path to image
argv[2]: path to ConvNet architecture
argv[3]: path to caffe model

e.g.
python3 recognise_id_number.py only_number_id_test/many_digit_groups/841289701567_0901328497_371447913_1_2016022909243414.jpgcardnumber.png lenet_deploy.prototxt mixed_lenet_8817_id_digit.caffemodel
